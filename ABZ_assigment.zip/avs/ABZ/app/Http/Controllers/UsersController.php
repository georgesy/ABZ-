<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Sub;
use App\Models\Driver;
use Carbon\Carbon;
class UsersController extends Controller
{
    
    public function subs(Request $request){
        $acc_id = $request->session()->get('acc_id');        
        $subs = DB::table('subs') 
        ->where('subs.acc_id',$acc_id)     
        ->join('drivers', 'drivers.id', '=', 'subs.acc_id') 
        ->join('vehicles', 'vehicles.id', '=', 'drivers.vehicle_id')                       
        ->select('vehicles.plate','subs.mpesa_code','subs.id','subs.phone','subs.state','subs.created_at')           
        ->get();
               
        return view('pages.users.subs', ['subs' => $subs]);
    }

    public function new_subs(Request $request){ 
        $rand = $this->generateRandomString();
        $acc_id = $request->session()->get('acc_id');
       
        $acc_info = Driver::find($acc_id);
        $id =  $acc_info['vehicle_id'];
       
        $acc_id = $request->session()->get('acc_id');        
        
        $subs =   DB::table('subs')->whereDate('created_at', DB::raw('CURDATE()'))->first();
        
        if($subs->state==1){
            return "Subscription Exists !!";
        }else if($subs->state==0){
            return "Subscription Waiting for Confirmation !!"; 
        }        
        try {           
            Sub::create([            
                'phone' => $request->phone,
                'mpesa_code' => $rand,
                'acc_id' => $acc_id,
                'vehicle_id' => $id,
                'state' => 0,                
            ]);

            return "Subscription Created, waiting for confirmation...";
        } catch (\Throwable $th) {
            return $th;
            return "Error Occured, Contact Tech Support";
        }      
    }

    function generateRandomString($length = 10) {
        $characters = '456RSAQWXBCDEFGHITUV9J78KLM0123NOPYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}
