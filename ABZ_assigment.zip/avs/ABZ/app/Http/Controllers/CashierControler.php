<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CashierControler extends Controller
{
    public function subs(){        
        $subs = DB::table('subs')       
        ->join('vehicles', 'vehicles.id', '=', 'subs.vehicle_id')                          
        ->select('vehicles.plate','subs.mpesa_code','subs.id','subs.phone','subs.state','subs.created_at')        
        ->get();         
        return view('pages.cashiers.subs', ['subs' => $subs]);
    }

    public function acc_opt(Request $request){        
        $id = $request->acc_id;
        $type = $request->type;       

        $update = DB::table('subs')
        ->where('id',$id)
        ->update(['state'=>$type]);        

        if($update){            
            return 1;
        }else{             
            return 2;            
        }
    }

    
}
