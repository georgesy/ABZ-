
<li >
    <a href="/accounts">
            <i class="fa fa-bank metismenu-icon primary_color"></i><strong>Managers </strong>                                   
    </a>                                
</li>
<li >
    <a href="/accounts">
            <i class="fa fa-exchange metismenu-icon primary_color"></i><strong>Cashier </strong>                                  
    </a>                                
</li>
<li >
    <a href="/accounts">
            <i class="fa fa-group metismenu-icon primary_color"></i><strong>Drivers  </strong>                                  
    </a>                                
</li>
<li >
    <a href="/accounts">
            <i class="fa fa-bus metismenu-icon primary_color"></i><strong>Vehicles  </strong>                                  
    </a>                                
</li>
