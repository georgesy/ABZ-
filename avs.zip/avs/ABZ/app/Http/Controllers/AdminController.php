<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Manager;
use App\Models\Terminus;
use App\Models\Cashier;
use App\Models\Vehicle;
use App\Models\Driver;
use App\Models\Sub;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function index(){
        return view('layout.master');
    }

    public function manager(){        
        $managers = DB::table('managers')       
        ->join('termini', 'termini.id', '=', 'managers.terminus_id')                             
        ->select('termini.name AS tname','termini.location','managers.name','managers.id','managers.phone','managers.email','managers.gender','managers.terminus_id','managers.active','managers.created_at')
        ->get();         
        $terminius = Terminus::get();        
        return view('pages.admin.manager', ['managers' => $managers,'terminus' => $terminius]);
    }

    public function save_manager(Request $request){
        $password = Hash::make("password123");
        $created =Manager::create([            
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'gender' => $request->gender,
            'terminus_id' => $request->terminus,
            'security' => 0,
            'active' => 1,
            'password' => $password
        ]);
        return "Accounted has been created successfull";
    }

    public function create_terminus(Request $request){        
       Terminus::create([            
            'name' => $request->name,
            'location' => $request->location            
        ]);
        return "Terminus has been created successfull";
    }

    public function cashier(){        
        $cashiers = DB::table('cashiers')       
        ->join('termini', 'termini.id', '=', 'cashiers.terminus_id')                             
        ->select('termini.name AS tname','cashiers.name','cashiers.id','cashiers.phone','cashiers.email','cashiers.gender','cashiers.terminus_id','cashiers.active','termini.location','cashiers.created_at')
        ->get();         
        $terminius = Terminus::get();        
        return view('pages.admin.cashiers', ['cashiers' => $cashiers,'terminus' => $terminius]);
    }

    public function new_cashier(Request $request){
        try {
            $password = Hash::make("password123");
            $created =Cashier::create([            
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'gender' => $request->gender,
                'terminus_id' => $request->terminus,
                'security' => 0,
                'active' => 1,
                'password' => $password
            ]);

            return "Accounted has been created successfull";
        } catch (\Throwable $th) {
            return $th;
        }      
        
    }

    public function suspend_acc(Request $request){        
        $id = $request->acc_id;
        $type = $request->type;
        $table = $request->table;

        $update = DB::table($table)
        ->where('id',$id)
        ->update(['active'=>$type]);        

        if($update){            
            return 1;
        }else{             
            return 2;            
        }
    }

    public function drivers(){        
        $drivers = DB::table('drivers')       
        ->join('vehicles', 'vehicles.id', '=', 'drivers.vehicle_id')                             
        ->select('vehicles.plate','drivers.name','drivers.id','drivers.phone','drivers.email','drivers.gender','drivers.vehicle_id','drivers.active','drivers.residence','drivers.created_at')
        ->get();         
        $vehicles = Vehicle::get();        
        return view('pages.admin.drivers', ['drivers' => $drivers,'vehicles' => $vehicles]);
    }

    public function new_driver(Request $request){
        try {
            $password = Hash::make("password123");
            $created =Driver::create([            
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'residence' => $request->residence,
                'gender' => $request->gender,
                'vehicle_id' => 2,
                'security' => 0,
                'active' => 1,
                'password' => $password
            ]);

            return "Driver has been created successfull";
        } catch (\Throwable $th) {
            return $th;
        }      
        
    }
    public function vehicles(){           
        $vehicles = Vehicle::get();        
        return view('pages.admin.vehicle', ['vehicles' => $vehicles]);
    }

    public function new_vehicle(Request $request){
        try {
           
            Vehicle::create([            
                'plate' => $request->plate,
                'capacity' => $request->capacity,
                'fleet_number' => $request->fleet,
            ]);

            return "Vehicle has been created successfull";
        } catch (\Throwable $th) {
            return "Error Occured, Contact Tech Support";
        }      
        
    }

    public function remove_vehicle(Request $request){ 

        try {
            $id = $request->id;            
            $vehicle=Vehicle::where('id',$id);
            $vehicle->delete();
            return 1;
        } catch (\Throwable $th) {
            return $th;
        }       
       
    }

    public function subs(){           
        $subs = Sub::get();        
        return view('pages.users.users', ['subs' => $subs]);
    }

    public function new_subs(Request $request){ 
        $rand = $this->generateRandomString();
          
        try {           
            Sub::create([            
                'phone' => $request->phone,
                'mpesa_code' => $rand,
                'state' => 0,                
            ]);

            return "Subscription Created, waiting for confirmation...";
        } catch (\Throwable $th) {
            return $th;
            return "Error Occured, Contact Tech Support";
        }      
    }

    function generateRandomString($length = 10) {
        $characters = '456RSAQWXBCDEFGHITUV9J78KLM0123NOPYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}
