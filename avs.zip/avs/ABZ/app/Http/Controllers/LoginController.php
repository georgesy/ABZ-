<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Manager;
use App\Models\Cashier;
use App\Models\Driver;
use App\Models\Admin;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function index(){        
        return view('pages.login');
    }

    public function auth_acc(Request $request){      
        $email = $request->email;
        $password = $request->password;
        $account = $request->account;
        $hash_password = Hash::make($password);      
       
        
        if($account == "admin"){
            $acc_level = 0;
            $email_count = Admin::where('email', '=', $request->email)                                                                      
                            ->count();   
            $acc_info = Admin::whereEmail($email)->first();         
        }else if($account == "managers"){
            $acc_level = 1;
            $email_count = Manager::where('email', '=', $request->email)                                                                      
                            ->count();  
            $acc_info = Manager::whereEmail($email)->first();

        }else if($account == "cashiers"){
            $acc_level = 2;
            $email_count = Cashier::where('email', '=', $request->email)                                                                      
                            ->count(); 
            $acc_info = Cashier::whereEmail($email)->first(); 
             

        }else if($account == "users"){
            $acc_level = 3;
            $email_count = Driver::where('email', '=', $request->email)                                                                      
                            ->count();
            $acc_info = Driver::whereEmail($email)->first(); 

        }else{
            $acc_level = 4;
            $email_count =0;            
        }      
        
        
        if($email_count>0){         
           
            if ($acc_info->active =="1") {
                    $hash_pass = $acc_info->password;

                if (Hash::check($password, $acc_info->password)) {
                    $request->session()->put('userType',$account);
                    $request->session()->put('acc_level',$acc_level);                                         
                    return $acc_level;
                    
                }else{
                    return "Incorrect details1";
                    // return Redirect::back()->withErrors(['msg', 'Incorrect Login Details']);
                }
            }else{
                return "Account Not active";
                // return Redirect::back()->withErrors(['msg', 'Account Not Active']);
            }
            
        }else{
            return "Error!!. Ensure you have selected the correct account type";
            // return Redirect::back()->withErrors(['msg', 'Incorrect Login Details']);
        }

          
    }

    public function logout(Request $request){
        $request->session()->forget('userType');      

        return redirect('/login');
    }

}
