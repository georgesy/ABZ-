<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsersController extends Controller
{
    
    public function subs(){        
        $subs = DB::table('subs')       
        ->join('vehicles', 'vehicles.id', '=', 'subs.vehicle_id')                          
        ->select('vehicles.plate','subs.mpesa_code','subs.id','subs.phone','subs.state','subs.created_at')        
        ->get();         
        return view('pages.users.subs', ['subs' => $subs]);
    }
}
