@extends('../../layout/master')
@section('content')
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
                        </div>
                            <div>Vehicles Information                         
                            </div>
                            </div>
                            <div class="page-title-actions">                                
                                <button class="mb-2 mr-2 btn-pill btn-hover-shine btn btn-primary" data-toggle="modal"  data-target="#exampleModal"
                                       > New Vehicle</button>                                                               
                            </div>    
                        </div>
                    </div>  
                    
                    <div class="main-card mb-3 card">
                <div class="card-body">
                    
                    <table style="width: 100%;" id="example"  class="table table-hover table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Id</th> 
                            <th>Fleet Number</th>
                            <th>Plate</th>                            
                            <th>Capacity</th>                                                     
                            <th>Date of Reg</th>                                    
                            <th>Control.</th>              
                        </tr>
                        </thead>
                        <tbody>  
                        @foreach($vehicles as $vehicle)
                            
                            <tr>
                                <td>{{$vehicle->id}}</td>
                                <td>{{$vehicle->fleet_number}}</td>
                                <td>{{$vehicle->plate}}</td>
                                <td>{{$vehicle->capacity}}</td>                       
                                <td>{{$vehicle->created_at}}</td>                            
                                <td>
                                    <button class=" btn btn-shadow mr-3 btn-danger" onclick="remove({{$vehicle->id}})">DELETE</button>                                  
                                </td>                      
                                    
                            </tr>

                            @endforeach                  
                        
                        </tbody>
                       
                    </table>
                </div>
            </div>             
                  
                </div>
                <div class="app-wrapper-footer">
                    <div class="app-footer">
                        <div class="app-footer__inner">
                            <div class="app-footer-left">
                                <div class="footer-dots">
                                    <div class="dropdown">
                                        <a aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="dot-btn-wrapper">
                                            <i class="dot-btn-icon lnr-bullhorn icon-gradient bg-mean-fruit"></i>
                                            <div class="badge badge-dot badge-abs badge-dot-sm badge-danger">Notifications</div>
                                        </a>
                                        
                                    </div>
                                    <div class="dots-separator"></div>
                                   
                                </div>
                            </div>                           
                        </div>
                    </div>
                </div>
            </div>
    
@endsection

<div class="modal fade bd-example-modal-lg"  id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">New Vehicle</h5><span id="title_id"></span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="">
                {{ csrf_field() }}
                    <div class="form-row">
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="exampleEmail11" class="">Plate No. </label>
                                <input  id="plate" placeholder="Enter Name " type="text" class="form-control">
                            </div>
                        </div>  
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="email" class="">Capacity</label>
                                <input  id="capacity" placeholder="Enter Capacity" type="text" class="form-control">
                            </div>
                        </div>  
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="email" class="">Fleet Number</label>
                                <input  id="fleet" placeholder="Enter Fleet Number" type="text" class="form-control">
                            </div>
                        </div>  
                        
                    </div>                     
                   
                    <div class="alert alert-warning" id="adj_alert1" style="display:none"><i class="fa fa-spinner fa-spin"></i>Saving Data. Please Wait..</div>               
                   
                </form>
            </div>
            <div class="modal-footer">
                <div >
                    <button type="button" class="btn btn-primary" onclick="add_vehicle()" id="btn_modal">SAVE</button>
                     
                </div>              
               
            </div>
        </div>
    </div>
</div>

@section('scripts')

<script>

function add_vehicle() {
        var plate = $('#plate').val(); 
        var capacity = $('#capacity').val();
        var fleet = $('#fleet').val();  
        
        
        if(plate.length && capacity.length){             
             $('#adj_alert1').fadeIn();   
            var formdata = new FormData;
            formdata.append('plate',plate);
            formdata.append('capacity',capacity);  
            formdata.append('fleet',fleet);             
           
            $.ajax({
                url: '/new_vehicle', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'POST',                     
                success: function(data){ 
                    console.log(data);  
                    $('#adj_alert1').fadeIn();                  
                    $('#adj_alert1').html(data); 
                    // setTimeout(function(){ location.reload(); }, 2000);           
                    
                }
            });  
        }else{
            $('#adj_alert1').fadeIn();
            $('#adj_alert1').html("Please Fill all the fields");            
        }
    }


function remove(id){ 
    
    if(confirm("Are you Sure you want to Proceed?")){    
        var formdata = new FormData;     
        formdata.append('id',id);            
        
        $.ajax({
            url: '/remove_vehicle', // point to server-side PHP script 
            dataType: 'text',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: formdata,    
            type: 'post',
            success: function(data){
                console.log(data);
                if(data==1) {                    
                alert("Action done  Successfully");
                setTimeout(function(){ location.reload(); }, 1000);
                }else{
                alert("Error Occured ......Try again");
                }                                       
            }

        });
        
    }
}


</script>

@endsection