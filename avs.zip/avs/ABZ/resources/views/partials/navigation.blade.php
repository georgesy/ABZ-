
    @if(Session::get('acc_level')==0)
        <li >
            <a href="/managers">
                    <i class="fa fa-bank metismenu-icon primary_color"></i><strong>Managers </strong>                                   
            </a>                                
        </li>
        <li >
            <a href="/cashier">
                    <i class="fa fa-exchange metismenu-icon primary_color"></i><strong>Cashier </strong>                                  
            </a>                                
        </li>
        <li >
            <a href="/drivers">
                    <i class="fa fa-group metismenu-icon primary_color"></i><strong>Drivers  </strong>                                  
            </a>                                
        </li>
       
    @elseif(Session::get('acc_level')==1)
         <li >
            <a href="/vehicles">
                    <i class="fa fa-bus metismenu-icon primary_color"></i><strong>Vehicles  </strong>                                  
            </a>                                
        </li>
        <li >
            <a href="/subscription">
                <i class="fa fa-money metismenu-icon primary_color"></i><strong>Subscriptions  </strong>                                  
            </a>                                
        </li>
    @elseif(Session::get('acc_level')==2)
        <li >
            <a href="/subs_cashier">
                    <i class="fa fa-bus metismenu-icon primary_color"></i><strong>Home  </strong>                                  
            </a>                                
        </li>

    @elseif(Session::get('acc_level')==3)
        <li >
            <a href="/subs_cashier">
                    <i class="fa fa-bus metismenu-icon primary_color"></i><strong>Home  </strong>                                  
            </a>                                
        </li>

    @elseif(Session::get('acc_level')==4)

    @else

    @endif
