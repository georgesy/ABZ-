<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ManagerControler;
use App\Http\Middleware\AuthUsersMiddleware;
use App\Http\Controllers\CashierControler;
use App\Http\Controllers\UsersController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware([AuthUsersMiddleware::class])->group(function () {
    Route::get('/managers',[AdminController::class, 'manager']);
    Route::post('/new_manager',[AdminController::class, 'save_manager']);
    Route::post('/new_terminus',[AdminController::class, 'create_terminus']);
    Route::get('/cashier',[AdminController::class, 'cashier']);
    Route::post('/new_cashier',[AdminController::class, 'new_cashier']);
    Route::post('/suspend_acc',[AdminController::class, 'suspend_acc']);
    Route::get('/drivers',[AdminController::class, 'drivers']);
    Route::post('/new_driver',[AdminController::class, 'new_driver']);   
    Route::post('/remove_vehicle',[AdminController::class, 'remove_vehicle']);
    Route::post('/new_vehicle',[AdminController::class, 'new_vehicle']);    
    

    Route::get('/vehicles',[ManagerControler::class, 'vehicles']);
    Route::get('/subscription',[ManagerControler::class, 'subs']);

    Route::get('/subs_cashier',[CashierControler::class, 'subs']);
    Route::post('/sub_opt',[CashierControler::class, 'acc_opt']);

    Route::get('/subs_users',[UsersController::class, 'subs']);
    Route::post('/new_subscription',[UsersController::class, 'new_subs']);

});
Route::get('/',[LoginController::class, 'index']);
Route::get('/login',[LoginController::class, 'index']);
Route::post('/login_auth',[LoginController::class, 'auth_acc']);
Route::get('/signout',[LoginController::class, 'logout']);



