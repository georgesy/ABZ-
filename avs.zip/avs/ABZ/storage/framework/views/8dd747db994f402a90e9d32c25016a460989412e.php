<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>ABZ Tuk Tuk Management System</title>
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="ArchitectUI HTML Bootstrap 4 Dashboard Template">

    <!-- Disable tap highlight on IE -->
    <meta name="msapplication-tap-highlight" content="no">
    
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"></head>
    <link href="custom.css" rel="stylesheet"></head>
    
    <link href="font-awesome-5.14.0/css/font-awesome.min.css'" rel="stylesheet" />



<body>
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd;">
  <a class="navbar-brand" href="#"> BVZ Managenent System <strong>LOGIN</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 
</nav>
    <div class="app-container app-theme-white body-tabs-shadow">
        <div class="app-container">
            <div class="h-100 bg-plum-plate bg-animation">
                <div class="d-flex h-100 justify-content-center align-items-center">
                    <div class="mx-auto app-login-box col-md-8">
                        <div class="app-logo-inverse mx-auto mb-3"></div>
                        <div class="modal-dialog w-100 mx-auto">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="h5 modal-title text-center">
                                        <h4 class="mt-2">
                                            <div>Please sign </div>
                                       
                                        </h4>
                                    </div>
                                   
                                    <form id="myform">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-row">
                                        <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <div><label for="email">Select Account Type</label></div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="inlineCheckbox" id="inlineCheckbox1" value="admin">
                                                        <label class="form-check-label" for="inlineCheckbox1">Admin</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="inlineCheckbox" id="inlineCheckbox1" value="managers">
                                                        <label class="form-check-label" for="inlineCheckbox1">Manager</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="inlineCheckbox" id="inlineCheckbox2" value="cashiers">
                                                        <label class="form-check-label" for="inlineCheckbox2">Cashier</label>
                                                        </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="inlineCheckbox" id="inlineCheckbox3" value="drivers" >
                                                        <label class="form-check-label" for="inlineCheckbox3">Users(driver)</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <label for="email">Email Field</label>
                                                    <input id="email"  placeholder="Email here..." type="email" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <label for="email">Password Field</label>
                                                    <input id="password" placeholder="Password here..." type="password" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="position-relative form-check">
                                            <input name="check" id="exampleCheck" type="checkbox" class="form-check-input">
                                            <label for="exampleCheck" class="form-check-label">Keep me logged in</label>
                                        </div>
                                    </form>
                                    
                                </div>
                                <div class="modal-footer clearfix">
                                    <div class="float-left">
                                        <a href="javascript:void(0);" class="btn-lg btn btn-link">Recover Password</a>
                                    </div>
                                    <div class="float-right">
                                        <button class="btn btn-primary btn-lg" onclick="login()">Login</button>
                                    </div>                                   
                                    
                                </div>                               
                                 <div class="alert alert-primary fade show" id="alert_infor_login" style="display:none">Authenticating Information</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
    
    <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-2.0.2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
       <script>
         $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
         });
    </script>   
     
     <script>
          function login(){
            $('#alert_infor_login').show();
            var email = $("#email").val().trim();
            var password = $("#password").val().trim();              
            
            var checkedValue = $("#myform input[type='radio']:checked").val();
            if(typeof(checkedValue)=="undefined"){
                $('#alert_infor_login').removeClass('alert-info');
                $('#alert_infor_login').addClass('alert-danger');
                $('#alert_infor_login').text("Please Select Account !!!");
                $('#alert_infor_login').fadeIn();
                return;
            }

            console.log(checkedValue);           
           
            if(email.length < 1 || password.length < 1){
                $('#alert_infor_login').removeClass('alert-info');
                $('#alert_infor_login').addClass('alert-danger');
                $('#alert_infor_login').text("Please Fill the Fields!!!");
                $('#alert_infor_login').fadeIn();
                return;
            }
            var formdata = new FormData;           
            formdata.append('email',email);
            formdata.append('password',password);
            formdata.append('account', checkedValue);

            $.ajax({
                    url: '/login_auth', // point to server-side PHP script 
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: formdata,
                    type: 'post',
                    success: function (e) {  
                                                                            
                        if (e == 0) {                           
                            window.location.href ='/managers';                            
                        }else if(e == 1){
                            window.location.href ='/vehicles'; 
                        }else if(e == 2){
                            window.location.href ='/subs_cashier';
                        }else if(e == 3){
                            window.location.href ='/subs_cashier';
                        } else if(e == 3){
                            window.location.href ='/country_city';
                        }else {
                            $('#alert_infor_login').removeClass('alert-info');
                            $('#alert_infor_login').addClass('alert-danger');
                            $('#alert_infor_login').text(e);
                            $('#alert_infor_login').fadeIn();
                        }
                    }
                });
           
         }
     </script>
        
</body>


<!-- Mirrored from demo.dashboardpack.com/architectui-html-pro/pages-login-boxed.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 17 Nov 2020 06:38:09 GMT -->
</html><?php /**PATH C:\wamp64\www\avs\ABZ\resources\views/pages/login.blade.php ENDPATH**/ ?>