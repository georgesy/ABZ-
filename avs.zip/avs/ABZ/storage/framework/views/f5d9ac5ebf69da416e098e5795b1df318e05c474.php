
<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
                        </div>
                            <div>Subscription Information                         
                            </div>
                            </div>
                            <div class="page-title-actions">                                
                                <button class="mb-2 mr-2 btn-pill btn-hover-shine btn btn-primary" data-toggle="modal"  data-target="#exampleModal"
                                       > New Subscription</button>                                                               
                            </div>    
                        </div>
                    </div>  
                    
                    <div class="main-card mb-3 card">
                <div class="card-body">
                    
                    <table style="width: 100%;" id="example"  class="table table-hover table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Id</th> 
                            <th>Mpesa Code</th>
                            <th>Phone</th>                                                        
                            <th>State</th>                                                     
                            <th>Payment Date/Time</th>                                
                        </tr>
                        </thead>
                        <tbody>
                             
                            <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php
                                if($sub->state==1){
                                    $state = '<p style="color:green">ACTIVE</p>';                 
                                    
                                }else {
                                    $state = '<p style="color:red">PENDING</p>';                            
                                }         

                              ?>
                                           
                            
                            <tr>
                                <td><?php echo e($sub->id); ?></td>
                                <td><?php echo e($sub->mpesa_code); ?></td>
                                <td><?php echo e($sub->phone); ?></td>
                                <td><?php echo $state?></td>                       
                                <td><?php echo e($sub->created_at); ?></td>                                  
                                    
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                        
                        </tbody>
                       
                    </table>
                </div>
            </div>             
                  
                </div>
                <div class="app-wrapper-footer">
                    <div class="app-footer">
                        <div class="app-footer__inner">
                            <div class="app-footer-left">
                                <div class="footer-dots">
                                    <div class="dropdown">
                                        <a aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="dot-btn-wrapper">
                                            <i class="dot-btn-icon lnr-bullhorn icon-gradient bg-mean-fruit"></i>
                                            <div class="badge badge-dot badge-abs badge-dot-sm badge-danger">Notifications</div>
                                        </a>
                                        
                                    </div>
                                    <div class="dots-separator"></div>
                                   
                                </div>
                            </div>                           
                        </div>
                    </div>
                </div>
            </div>
    
<?php $__env->stopSection(); ?>

<div class="modal fade bd-example-modal-lg"  id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">New Subscription</h5><span id="title_id"></span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="">
                <?php echo e(csrf_field()); ?>

                    <div class="form-row">
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="exampleEmail11" class="">Enter Phone </label>
                                <input  id="phone" placeholder="Type Phone Number " type="text" class="form-control">
                            </div>
                        </div>  
                        
                        
                    </div>                     
                   
                    <div class="alert alert-warning" id="adj_alert1" style="display:none"><i class="fa fa-spinner fa-spin"></i> Simulation MPESA push STK. Please Wait..</div>               
                   
                </form>
            </div>
            <div class="modal-footer">
                <div >
                    <button type="button" class="btn btn-primary" onclick="add_sub()" id="btn_modal">PAY!</button>
                     
                </div>              
               
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>

<script>

function add_sub() {
    var phone = $('#phone').val();     
    if(phone.length){             
        $('#adj_alert1').fadeIn();   
        var formdata = new FormData;
        formdata.append('phone',phone);               
        
        $.ajax({
            url: '/new_subscription', // point to server-side PHP script 
            dataType: 'text',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: formdata,    
            type: 'POST',                     
            success: function(data){ 
                console.log(data);  
                $('#adj_alert1').fadeIn();                  
                $('#adj_alert1').html(data); 
                // setTimeout(function(){ location.reload(); }, 2000);           
                
            }
        });  
    }else{
        $('#adj_alert1').fadeIn();
        $('#adj_alert1').html("Please Fill all the fields");            
    }
}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avs\ABZ\resources\views/pages/users/users.blade.php ENDPATH**/ ?>