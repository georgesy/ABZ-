<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vehicle;
use App\Models\Sub;
use Illuminate\Support\Facades\DB;

class ManagerControler extends Controller
{
    public function vehicles(){           
        $vehicles = Vehicle::get();        
        return view('pages.admin.vehicle', ['vehicles' => $vehicles]);
    }

    public function new_vehicle(Request $request){
        try {
           
            Vehicle::create([            
                'plate' => $request->plate,
                'capacity' => $request->capacity,
                'fleet_number' => $request->fleet,
            ]);

            return "Vehicle has been created successfull";
        } catch (\Throwable $th) {
            return "Error Occured, Contact Tech Support";
        }      
        
    }

    public function remove_vehicle(Request $request){ 

        try {
            $id = $request->id;            
            $vehicle=Vehicle::where('id',$id);
            $vehicle->delete();
            return 1;
        } catch (\Throwable $th) {
            return $th;
        }       
       
    }

    public function subs(){    
        
        $subs = DB::table('subs')       
        ->join('vehicles', 'vehicles.id', '=', 'subs.vehicle_id')                          
        ->select('vehicles.plate','subs.mpesa_code','subs.id','subs.phone','subs.state','subs.created_at')        
        ->get();         
        return view('pages.manager.subs', ['subs' => $subs]);
    }



}
