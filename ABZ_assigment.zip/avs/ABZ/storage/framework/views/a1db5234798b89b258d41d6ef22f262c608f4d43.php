
<?php $__env->startSection('content'); ?>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        <div class="page-title-icon">
                            <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
                        </div>
                            <div>Terminus Cashiers                         
                            </div>
                            </div>
                            <div class="page-title-actions">                                
                                <button class="mb-2 mr-2 btn-pill btn-hover-shine btn btn-primary" data-toggle="modal"  data-target="#exampleModal"
                                       > New Cashier</button>                                                               
                            </div>    
                        </div>
                    </div>  
                    
                    <div class="main-card mb-3 card">
                <div class="card-body">
                    
                    <table style="width: 100%;" id="example"  class="table table-hover table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Name</th>                            
                            <th>Email</th>
                            <th>Terminus</th>
                            <th>Account State</th>                           
                            <th>Date of Reg</th>                                    
                            <th>Control.</th>              
                        </tr>
                        </thead>
                        <tbody>  
                        <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php                                
                                if($cashier->active==1){
                                    $state = '<p style="color:green">ACTIVE</p>';                                        
                                    $badge = 'badge-danger'; 
                                    $btn_msg = "SUSPEND";  
                                    $val = 0; 
                                    
                                }else {
                                    $state = '<p style="color:red">SUSPENDED</p>';
                                    $badge = 'badge-success';                                    
                                    $btn_msg = "ACTIVATE"; 
                                    $val = 1;  
                                }                            
                               
                                

                            ?>
                            <tr>
                                <td><?php echo e($cashier->name); ?></td>
                                <td><?php echo e($cashier->email); ?></td>                           
                                <td><?php echo e($cashier->tname); ?></td>                           
                                <td><?php echo $state?></td>
                                <td><?php echo e($cashier->created_at); ?></td>                            
                                <td>
                                    <button class=" btn btn-shadow mr-3 <?php echo e($badge); ?>" onclick="acc_opt(<?php echo e($val); ?>,<?php echo e($cashier->id); ?>)"><?php echo e($btn_msg); ?></button>                                  
                                </td>                      
                                    
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                            
                        
                        
                        </tbody>
                       
                    </table>
                </div>
            </div>             
                  
                </div>
                <div class="app-wrapper-footer">
                    <div class="app-footer">
                        <div class="app-footer__inner">
                            <div class="app-footer-left">
                                <div class="footer-dots">
                                    <div class="dropdown">
                                        <a aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" class="dot-btn-wrapper">
                                            <i class="dot-btn-icon lnr-bullhorn icon-gradient bg-mean-fruit"></i>
                                            <div class="badge badge-dot badge-abs badge-dot-sm badge-danger">Notifications</div>
                                        </a>
                                        
                                    </div>
                                    <div class="dots-separator"></div>
                                   
                                </div>
                            </div>                           
                        </div>
                    </div>
                </div>
            </div>
    
<?php $__env->stopSection(); ?>

<div class="modal fade bd-example-modal-lg"  id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">New Cashier</h5><span id="title_id"></span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="">
                <?php echo e(csrf_field()); ?>

                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="exampleEmail11" class="">Name </label>
                                <input  id="name" placeholder="Enter Name " type="text" class="form-control">
                            </div>
                        </div>  
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="email" class="">Enter Email</label>
                                <input  id="email" placeholder="Enter Email" type="text" class="form-control">
                            </div>
                        </div>  
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="phone" class="">Enter Phone</label>
                                <input  id="phone" placeholder="Please Type Phone" type="text" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="email" class="">Enter Gender</label>
                                <select class="form-control" id="gender">
                                    <option value="0">Select Option</option>
                                    <option value="Female">Female</option>
                                    <option  value="Male">Male</option>
                                    <option  value="Others">Other</option>
                                </select>
                            </div>
                        </div>   
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="email" class="">Select Terminus</label>
                                <select class="form-control" id="terminus">
                                    <?php $__currentLoopData = $terminus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $termius): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($termius ->id); ?>"><?php echo e($termius->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </select>
                            </div>
                        </div>   
                    </div>                     
                   
                    <div class="alert alert-warning" id="adj_alert1" style="display:none"><i class="fa fa-spinner fa-spin"></i>Saving Data. Please Wait..</div>               
                   
                </form>
            </div>
            <div class="modal-footer">
                <div >
                    <button type="button" class="btn btn-primary" onclick="save_cashier()" id="btn_modal">SAVE</button>
                     
                </div>              
               
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>

<script>

function save_cashier() {
        var name = $('#name').val(); 
        var email = $('#email').val();  
        var gender = $('#gender').val();    
        var terminus = $('#terminus').val(); 
        var phone = $('#phone').val();      
        
        if(name.length && email.length && gender.length && phone.length && terminus !=0){ 
            console.log("Hapa");  
             $('#adj_alert1').fadeIn();   
            var formdata = new FormData;
            formdata.append('name',name);
            formdata.append('email',email);
            formdata.append('gender',gender);
            formdata.append('phone',phone);
            formdata.append('terminus',terminus);            
           
            $.ajax({
                url: '/new_cashier', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'POST',                     
                success: function(data){ 
                    console.log(data);                    
                    $('#adj_alert1').html(data); 
                    // setTimeout(function(){ location.reload(); }, 2000);           
                    
                }
            });  
        }else{
            $('#adj_alert1').fadeIn();
            $('#adj_alert1').html("Please Fill all the fields");            
        }
    }

function create_terminus() {
        var tName = $('#tName').val(); 
        
        if(tName.length > 1){             
            $('#adj_alert1').fadeIn();   
            var formdata = new FormData;
            formdata.append('name',tName);                  
           
            $.ajax({
                url: '/new_terminus', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'POST',                     
                success: function(data){ 
                    console.log(data);  
                    $('#adj_alert1').fadeIn();                  
                    $('#adj_alert1').html(data); 
                    // setTimeout(function(){ location.reload(); }, 2000);                   
                }
            });  
        }else{
            $('#adj_alert1').fadeIn();
            $('#adj_alert1').html("Please fill  the required fields");            
        }
    }
 
function acc_opt(type,id){ 
    
    if(confirm("Are you Sure you want to Proceed?")){    
        var formdata = new FormData;    
        formdata.append('type',type);
        formdata.append('acc_id',id);
        formdata.append('table','cashiers');     
        
        $.ajax({
            url: '/suspend_acc', // point to server-side PHP script 
            dataType: 'text',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: formdata,    
            type: 'post',
            success: function(data){
                if(data==1) {                    
                alert("Action done  Successfully");
                setTimeout(function(){ location.reload(); }, 1000);
                }else{
                alert("Error Occured ......Try again");
                }                                       
            }

        });
        
    }
}


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avs\ABZ\resources\views/pages/admin/cashiers.blade.php ENDPATH**/ ?>