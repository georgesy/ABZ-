
function modal_show(m,p,id){  
  $('#menu_id').text(id);
  $('#meal_name').val(m);
  $('#meal_cost').val(p);
}

function save_edited(){
  var meal_id = $('#menu_id').text();
  var meal_name = $('#meal_name').val();
  var meal_cost =  $('#meal_cost').val();
  var meal_cat = $('#cat_meal').val();

  if(!meal_name.length || !meal_cost.length){
    alert("Please Fill all the fields");
    return;
  }
  if (meal_cat ==0) {
    alert("Please select Category");
    return;
  }  
  var formdata = new FormData();
  formdata.append('meal_id',meal_id);
  formdata.append('meal_name',meal_name);
  formdata.append('meal_cost',meal_cost);
  formdata.append('meal_cat', meal_cat);  

  $.ajax({
    url: '/update_menu', // point to server-side PHP script 
    dataType: 'text',  // what to expect back from the PHP script, if anything
    cache: false,
    contentType: false,
    processData: false,
    data: formdata,
    type: 'post',
    success: function (data) {
      if (data == 1) {
        alert("Update Successfull");
      }else{
        alert("Error Occured. Try again...")
      }
    }

  });
}

function save_new_meal() {  
  var meal_name = $('#meal_name1').val();
  var meal_cost = $('#meal_cost1').val();
  var meal_cat = $('#cat_meal1').val();

  if (!meal_name.length || !meal_cost.length) {
    alert("Please Fill all the fields");
    return;
  }
  if (meal_cat == 0) {
    alert("Please select Category");
    return;
  }
  var formdata = new FormData();  
  formdata.append('meal_name', meal_name);
  formdata.append('meal_cost', meal_cost);
  formdata.append('meal_cat', meal_cat);

  $.ajax({
    url: '/new_menu_single', // point to server-side PHP script 
    dataType: 'text',  // what to expect back from the PHP script, if anything
    cache: false,
    contentType: false,
    processData: false,
    data: formdata,
    type: 'post',
    success: function (data) {
      if (data == 1) {
        alert("Added Successfully");
        location.reload();
      } else {
        alert("Error Occured. Try again...")
      }
    }

  });
}

function suspend(id){
    if (confirm("Are you Sure you want to Suspend the meal?")) {
      var formdata = new FormData;      
      formdata.append('id', id);      

      $.ajax({
        url: '/suspend_meal', // point to server-side PHP script 
        dataType: 'text',  // what to expect back from the PHP script, if anything
        cache: false,
        contentType: false,
        processData: false,
        data: formdata,
        type: 'post',
        success: function (data) {
          if (data == 1) {
            alert("Action Successfull");
            location.reload();
          } else {
              alert("Error Occured. Try again")
          }

        }

      });

    }
}

function remove(id) {
  if (confirm("Are you Sure you want to DELETE the meal?")) {
    var formdata = new FormData;
    formdata.append('id', id);

    $.ajax({
      url: '/remove_meal', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,
      type: 'post',
      success: function (data) {
        if (data == 1) {
          alert("Deleted Successfully");
          location.reload();
        } else {
          alert("Error Occured. Try again")
        }

      }

    });

  }
}

function activate(id) {
  if (confirm("Are you Sure you want to make the meal Available?")) {
    var formdata = new FormData;
    formdata.append('id', id);

    $.ajax({
      url: '/activate_meal', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,
      type: 'post',
      success: function (data) {
        if (data == 1) {
          alert("Action done Successfully");
          location.reload();
        } else {
          alert("Error Occured. Try again")
        }

      }

    });

  }
}

function save_menu() {
  var table = document.getElementById('table_menu');
  var rows_length = table.rows.length;
  var row_count = 0 
  var formdata = new FormData();
  var data = " ";
  
  for (var i = 1; i < rows_length; i++) {
    
    var cell1 = table.rows[i].cells[0].getElementsByTagName('input')[0].value;
    var cell2 = table.rows[i].cells[1].getElementsByTagName('select')[0].value;
    var cell3 = table.rows[i].cells[2].getElementsByTagName('input')[0].value;
    var m = i-1;

    if(cell1.length >1 && cell3.length >1 && cell2>0){     
        var tbdata = cell1 + "|" + cell2+"|"+cell3;
        data += tbdata + "#";
        row_count++;     
    }
    
  }
  
  formdata.append('data', data);
  formdata.append('row_count', row_count);
  
  if(row_count>1){    
    $.ajax({
      url: '/add_menu_multiple', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,
      type: 'post',
      success: function (data) {
        alert(data);
        if (data.includes('Error')) {
          $('#alert-info').fadeIn();
          $('#alert-info').removeClass('alert-info');
          $('#alert-info').removeClass('alert-success');
          $('#alert-info').addClass('alert-danger');
          $('#alert-info').text(data);
        } else {
          $('#alert-info').fadeIn();
          $('#alert-info').removeClass('alert-info');
          $('#alert-info').removeClass('alert-danger');
          $('#alert-info').addClass('alert-success');
          $('#alert-info').text(data);
        }


      }

    });

  }else {
    alert("No Record to save");
  }
  
  
}

function save_category() {
  var cat_name = $("#cat_name").val().trim();
  if(cat_name.length<=1){
    alert("Please Type Something");
    return;
  }
  var formdata = new FormData;
  formdata.append('cat_name', cat_name);

  $.ajax({
    url: 'new_category', // point to server-side PHP script 
    dataType: 'text',  // what to expect back from the PHP script, if anything
    cache: false,
    contentType: false,
    processData: false,
    data: formdata,
    type: 'post',
    success: function (data) {
      if (data == 1) {
        alert("Added Successfull");
      }
    }

  });
}

function saveEditedCategory() {
  var cat_name = $("#cat_name1").val().trim();
  var cat_id = $("#cat_id").text().trim();
  if (cat_name.length <= 1) {
    alert("Please Type Something");
    return;
  }
  var formdata = new FormData;
  formdata.append('cat_name', cat_name);
  formdata.append('cat_id', cat_id);

  $.ajax({
    url: 'edit_cat', // point to server-side PHP script 
    dataType: 'text',  // what to expect back from the PHP script, if anything
    cache: false,
    contentType: false,
    processData: false,
    data: formdata,
    type: 'post',
    success: function (data) {
      if (data == 1) {
        alert("Edited Successfull");
        location.reload();
      }else{
        alert("Error OCcured.Try again ..");
      }
    }

  });
}

function del_cat(cat_id) {  
  var formdata = new FormData;  
  formdata.append('cat_id', cat_id);

  $.ajax({
    url: 'del_cat', // point to server-side PHP script 
    dataType: 'text',  // what to expect back from the PHP script, if anything
    cache: false,
    contentType: false,
    processData: false,
    data: formdata,
    type: 'post',
    success: function (data) {
      if (data == 1) {
        alert("Delete Successfull");
        location.reload();
      } else {
        alert("Error OCcured.Try again ..");
      }
    }

  });
}


function edit_cat(id,name){
  $('#cat_id').text(id);
  $('#cat_name1').val(name);
  
}






/* used functio */






function check_int(m){
  if(m ==parseInt(m,10)){
    return 1;
  }else{
    return 0;
  }
}

function display_chatbox1(){
  $('#msgModal2').fadeIn();
  window.setInterval(function(){

  },3000);
}

function display_chatbox(){
  $('#myDirectChat1').fadeIn();
  var formdata = new FormData;
  formdata.append('stage','msg_read');

  $.ajax({
    url: '././netcrad.php', // point to server-side PHP script 
    dataType: 'text',  // what to expect back from the PHP script, if anything
    cache: false,
    contentType: false,
    processData: false,
    data: formdata,    
    type: 'post',
    success: function(data){     
      if(data==1){
        $('#msg_unread').text('0');
        var scrolltoh = $('#chatbody')[0].scrollHeight;
         $('#chatbody').scrollTop(scrolltoh);
      }
    }

  });
}


function load_rows(){  
  var rows = $('#rowz').val();
  var cat = $('#select_cat').val();
  if(cat==0){
    alert("Please select Category");
    return;
  }
  $('#container_rows').empty();   
  var tbody = document.getElementById('container_rows');  
  if(rows >0 || rows!=""){
   $('#msgModal').fadeIn();     
  for(var i=0;i<rows;i++){
      var tr = document.createElement('TR');
      tbody.appendChild(tr);
      for(var m=0;m<2;m++){
        var input1 = '<input type="text" class="form-control">';
        var td = document.createElement('TD');
        td.append(input1);
        var app_td = tr.appendChild(td);
        //   var input = document.createElement("input");
        //   input.type = "text";
        //   input.id = 'in'+i+m; 
        //   input.class = "form-control"         
          app_td.appendChild(input1);   
        
      }

    }

  }else{
    alert("Please Enter the number of meals to be added");
  }
}

function close_modal(){  
  $('#msgModal').fadeOut();
  var tbody= document.getElementById('breakfast_meals_modal');
  $('#breakfast_meals_modal').empty();
  $('#input_breakfast').val('');
}


function close_modal1(){  
  $('#msgModal1').fadeOut();
  // var tbody= document.getElementById('breakfast_meals_modal_update');
  $('#breakfast_meals_modal_update').empty();
  
}

function close_modal2(){
  $('#msgModal2').fadeOut()
}


function save(meal_category){ 
  var table = document.getElementById('modal_table_breakfast');
  var rows_length = table.rows.length;
  var cells_length = table.rows[0].cells.length;
  var formdata = new FormData();
  var data_length = 0;
  for(var i=1;i<rows_length;i++){           
      var cell1 = table.rows[i].cells[0].getElementsByTagName('input')[0].value;
      var cell2 = table.rows[i].cells[1].getElementsByTagName('input')[0].value; 
      var q = i-1;  
      var file_ava = $('#file_upload'+q).val();  
      if(cell1 != "" || cell2 !=""){
        data_length ++;
        if(file_ava != ""){          
        var file_obj = $("#file_upload"+q).prop("files")[0];
        var file_ext = $("#file_upload"+q).val().split('.').pop().toLowerCase();        
        var file_size = $("#file_upload"+q)[0].files[0].size; 
     
        if($.inArray(file_ext,["jpg","png","gif","jpeg"])!=-1) {        
          if(file_size<500000){
            $('#alert-info').fadeIn();
            $('#alert-info').addClass('alert-warning');
            $('#alert-info').html("<i class=\"fa fa-spinner fa-spin\"></i> Saving Records");
            var file = "file"+i;
             formdata.append(i,cell1+'|'+cell2);
             formdata.append(file,file_obj);
             formdata.append('file_state'+i,'1');                      
            }else{
              continue;
            } 
          
          }else{
            alert("File type NOT ALLOWED");
            return null;
          }
        }else{         
          formdata.append('file_state'+i,'0');
          formdata.append(i,cell1+'|'+cell2);
        }

        }else{
          continue;
        }
      }
      
        formdata.append('rows_length',data_length);  
        formdata.append('stage',"save_meal");
        formdata.append('meal_category',meal_category);        
        $.ajax({
              url: '././netcrad.php', // point to server-side PHP script 
              dataType: 'text',  // what to expect back from the PHP script, if anything
              cache: false,
              contentType: false,
              processData: false,
              data: formdata,    
              type: 'post',
              success: function(data){alert(data);
                if(data  != 0) {
                  if(data==rows_length-1){
                    $('#alert-info').fadeIn();
                    $('#alert-info').addClass('alert-success');
                    $('#alert-info').text("Records Added Successfully");
                  }else{
                    $('#alert-info').fadeIn();
                    $('#alert-info').addClass('alert-success');
                    $('#alert-info').text(data+" Records Added Successfully");
                  }
                 
                }else{
                  $('#alert-info').fadeIn();
                  $('#alert-info').addClass('alert-danger');
                  $('#alert-info').innerHTML = "Error Occured... Try Again";
                }                                    
              }

             });
}

function edit_meal(id,element,table){
   document.getElementById('meal_id').innerHTML = id;
   var table = document.getElementById('datatable-buttons');
   var modal_table = document.getElementById('modal_table_breakfast_update');
   var tbody= document.getElementById('breakfast_meals_modal_update');  
   // alert(table.)       
   $('#msgModal1').fadeIn(); 
   var tr = document.createElement('TR');
      tbody.appendChild(tr);
      var td1 = document.createElement('TD');
      var td2 = document.createElement('TD');
      var td3 = document.createElement('TD');
      var app_td1 = tr.appendChild(td1);
      var app_td2 = tr.appendChild(td2);
      var app_td3 = tr.appendChild(td3);
      var input = document.createElement("input");
      input.id = 'edit_meall';
      var input1 = document.createElement("input");
      input1.id = 'meal_cost';
      var input_file = document.createElement("input");
      input_file.type = 'file';
      input_file.id = 'file_id';
      app_td1.appendChild(input);
      app_td2.appendChild(input1);
      app_td3.appendChild(input_file);
      var row = element.closest('tr').rowIndex;
      $('#edit_meall').val(table.rows[row].cells[1].innerHTML);
      $('#meal_cost').val(table.rows[row].cells[2].innerHTML);

    }

function update(category){
  var table = document.getElementById('modal_table_meal_update'); 
  var meal_id = $('#meal_id').text();
  
  var formdata = new FormData();          
      var cell1 = table.rows[1].cells[0].getElementsByTagName('input')[0].value;
      var cell2 = table.rows[1].cells[1].getElementsByTagName('input')[0].value;
      var cell3 = table.rows[1].cells[2].getElementsByTagName('input')[0].value;
      if(cell2.length >0 && cell1.length >0 ){  
        if( cell3.length >0){           
        var file_obj = $("#file_id").prop("files")[0];
        var file_ext = $("#file_id").val().split('.').pop().toLowerCase();        
        var file_size = $("#file_id")[0].files[0].size; 
        if(file_size<500000){
          if($.inArray(file_ext,["jpg","png","gif","jpeg"])!=-1) { 
             formdata.append('cell_data',cell1+'|'+cell2);
             formdata.append('file',file_obj);
             formdata.append('id',meal_id);  
             formdata.append('stage',"update_meal"); 
             formdata.append('meal_category',category)          
            }else{
              alert("File Type Not Allowed");
              return null;
            } 
          
          }else{
            alert("File size is too big");
            return null;
          }
        }else{        
          formdata.append('cell_data',cell1+'|'+cell2);
          formdata.append('id',meal_id);
          formdata.append('stage',"update_meal1"); 
          formdata.append('meal_category',category)

        }

        }else{
          alert("Please Fill all the fields");
          return null;
        }
    
        $.ajax({
              url: '././netcrad.php', // point to server-side PHP script 
              dataType: 'text',  // what to expect back from the PHP script, if anything
              cache: false,
              contentType: false,
              processData: false,
              data: formdata,    
              type: 'post',
              success: function(data){
                if(data!=0){
                  alert(data);
                 location.reload();
                }else{
                  alert(data);
                }                                       
              }

             });

}

function delete_meal(id,element,category){ 
  if(confirm("Are you Sure you want to delete?")){    
      var formdata = new FormData;
      formdata.append('stage','delete_meal');
      formdata.append('id',id);
      formdata.append('category',category);

        $.ajax({
              url: '././netcrad.php', // point to server-side PHP script 
              dataType: 'text',  // what to expect back from the PHP script, if anything
              cache: false,
              contentType: false,
              processData: false,
              data: formdata,    
              type: 'post',
              success: function(data){                
                if(data==1) {
                  var roww_index = element.closest('tr').rowIndex;
                  document.getElementById('datatable-buttons').deleteRow(roww_index);
                  alert("Record Deleted Successfully");
                  window.location = window.location;
                }else{
                  alert("Error Occured ......Try again");
                }                                       
              }

             });
      
    }
}



function suspend_meal(id,element,category,roww){
   var row = element.closest('tr').rowIndex;   
   var state = document.getElementById(roww).getAttribute('value');  
  if(state==1){ 
    if(confirm("Are you Sure you want to Suspend the meal?")){    
        var formdata = new FormData;    
        formdata.append('stage','suspend_meal');
        formdata.append('id',id);
        formdata.append('state',state);
        formdata.append('category',category);

          $.ajax({
                url: '././netcrad.php', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'post',
                success: function(data){
                  if(data==1) {
                    var table = document.getElementById('datatable-buttons');
                    if(state==1){
                      $("#breakfast-meals").load(location.href+" #breakfast-meals>*"," "); 
                      // document.getElementById(roww).setAttribute('value','0');                      
                      //  $('#btn'+roww).removeClass('bluish');
                      //  $('#btn'+roww).addClass('orange');
                      //  document.getElementById('btn'+roww).text("Unavailable");
                      //  document.getElementById(roww).setAttribute('title','Activate');
                    }else{
                      $("#breakfast-meals").load(location.href+" #breakfast-meals>*"," ");
                      // document.getElementById(roww).setAttribute('value','1');
                      //  $('#btn'+roww).removeClass('orange');
                      //  $('#btn'+roww).addClass('bluish');
                      //  document.getElementById('btn'+roww).text("Available");
                      //  document.getElementById(roww).setAttribute('title','Suspend');
                    }
                    
                    alert("Record Suspended Successfully");
                  }else{
                    alert("Error Occured ......Try again");
                  }                                       
                }

               });
          
      }
    }else{
      if(confirm("Are you Sure you want to Activate the meal?")){
     
        var formdata = new FormData;    
        formdata.append('stage','suspend_meal');
        formdata.append('id',id);
        formdata.append('state',state);
        formdata.append('category',category);


          $.ajax({
                url: '././netcrad.php', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'post',
                success: function(data){
                  if(data==1) {
                    var table = document.getElementById('datatable-buttons');
                    if(state==1){
                      document.getElementById(row).setAttribute('value','0');
                      table.rows[row].cells[4].innerHTML ="<button class=\"btn btn-round btn-warning\">Unavailable</button>";
                      $('#'+row).removeClass('bluish');
                      $('#'+row).addClass('orange');
                      document.getElementById(row).setAttribute('title','Activate');
                    }else{
                      document.getElementById(row).setAttribute('value','1');
                      $('#'+row).removeClass('orange');
                      $('#'+row).addClass('bluish');
                       table.rows[row].cells[4].innerHTML = "<button class=\"btn btn-round btn-info\">Available</button>";
                       document.getElementById(row).setAttribute('title','Suspend');
                    }
                    
                    alert("Record Activated Successfully");
                  }else{
                    alert("Error Occured ......Try again");
                  }                                       
                }

               });
          
      }
    }
}

function Save_advert(){
  var sdate = $('#sdate').val();
  var fdate = $('#fdate').val();
  var file_obj = $('#file_advert').prop("files")[0];
  var description = $('#desc').val();
  var formdata = new FormData;
  
  if(sdate.length >0 && fdate.length >0 && description.length>0){ 

        
        var file_ext = $("#file_advert").val().split('.').pop().toLowerCase();        
        var file_size = $("#file_advert")[0].files[0].size; 
        if(file_size<500000){
          if($.inArray(file_ext,["jpg","png","gif","jpeg"])!=-1) { 
             formdata.append('start_date',sdate);
             formdata.append('end_date',fdate);
             formdata.append('file',file_obj);   
             formdata.append('desc',description);          
             formdata.append('stage',"advert_set");  

             $.ajax({
                url: '././netcrad.php', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'post',
                success: function(data){
                alert(data);
                  }
                });            
                            
            }else{
              alert("File Type Not Allowed");
              return null;
            } 
          
          }else{
            alert("File size is too big");
            return null;
          }
       

        }else{
          alert("Please Fill all the fields");
          return null;
        }  
}

function cashiers_priv(elementg){
  var doc = document.getElementById("cashiers_priv");
  var data = $('#cashiers_priv').val();
  var stored_val = $('#readonly_priv').val();
  $('#readonly_priv').val(stored_val+","+data);
  var priv_title = doc.options[parseInt(data)-1].innerHTML;
  var id_val = 'priv'+data;
  var btn = document.createElement("button");
  btn.setAttribute('text',priv_title);
  btn.setAttribute('title','Click To Remove');
  btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');
  btn.setAttribute('id',id_val);
  btn.appendChild(document.createTextNode(priv_title));  
  btn.addEventListener("click",remove_privv.bind(null,id_val,data));   

   $('#well_privv').append(btn);
 
  // $('#well_privv').append("<button class=\"btn btn-round btn-primary adj_btn_margin_below\" id=\"btn_gtrop\" title=\"Click To Remove\" onclick=\"remove_privv("+data+")\">"+priv_title+"</button>"); 


}

function remove_privv(element,index){  
  alert(element+" "+index);
  $("#"+element).hide();
  var stored_val = $('#readonly_priv').val();
  alert(stored_val);
  var array = stored_val.split(",");
  var ind = array.indexOf(index);
  array.splice(ind,1);
  $('#readonly_priv').val(array);
  alert(ind+" "+array);
}

function Save_cashier(){
  var name = $("#fname").val();
  var email = $("#email").val();
  var gender = $("#gender").val();
  var priv = $('#readonly_priv').val();

  var formdata = new FormData;
   formdata.append('fname',name);
   formdata.append('email',email);
   formdata.append('gender',gender);   
   formdata.append('priv',priv); 
   formdata.append('stage','save_cashier');         
 
   $.ajax({
      url: '././netcrad.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
      alert(data);
        }
      });            
                       
}

function suspend_cashier(id,element){  
   var row = element.closest('tr').rowIndex;  
   var state = document.getElementById(row).getAttribute('value');
    
  if(state==1){ 
    if(confirm("Are you Sure you want to Suspend Cashier Account?")){    
        var formdata = new FormData;    
        formdata.append('stage','suspend_cashier_acc');
        formdata.append('id',id);
        formdata.append('state',state);
        formdata.append('category',category);

          $.ajax({
                url: '././netcrad.php', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'post',
                success: function(data){                  
                  if(data==1) {
                    var table = document.getElementById('datatable-buttons');
                    if(state==1){
                      document.getElementById(row).setAttribute('value','0');                      
                       $('#'+row).removeClass('bluish');
                       $('#'+row).addClass('orange');
                      document.getElementById(row).setAttribute('title','Activate');
                    }else{
                      document.getElementById(row).setAttribute('value','1');
                       $('#'+row).removeClass('orange');
                       $('#'+row).addClass('bluish');                 
                       document.getElementById(row).setAttribute('title','Suspend');
                    }
                    
                    alert("Record Suspended Successfully");
                  }else{
                    alert("Error Occured ......Try again");
                  }                                       
                }

               });
          
      }
    }else{
      if(confirm("Are you Sure you want to Activate the meal?")){     
        var formdata = new FormData;    
        formdata.append('stage','suspend_cashier_acc');
        formdata.append('id',id);
        formdata.append('state',state);
        formdata.append('category',category);

          $.ajax({
                url: '././netcrad.php', // point to server-side PHP script 
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: formdata,    
                type: 'post',
                success: function(data){
                  if(data==1) {                    
                    if(state==1){
                      document.getElementById(row).setAttribute('value','0');                    
                      $('#'+row).removeClass('bluish');
                      $('#'+row).addClass('orange');
                      document.getElementById(row).setAttribute('title','Activate');
                    }else{
                      document.getElementById(row).setAttribute('value','1');
                      $('#'+row).removeClass('orange');
                      $('#'+row).addClass('bluish');
                     
                       document.getElementById(row).setAttribute('title','Suspend');
                    }
                    
                    alert("Record Activated Successfully");
                  }else{
                    alert("Error Occured ......Try again");
                  }                                       
                }

               });
          
      }
    }
}

function delete_cashier(id,element){ 
  if(confirm("Are you Sure you want to delete Cashier Account?")){    
      var formdata = new FormData;
      formdata.append('stage','delete_cashier');
      formdata.append('id',id);     

        $.ajax({
              url: '././netcrad.php', // point to server-side PHP script 
              dataType: 'text',  // what to expect back from the PHP script, if anything
              cache: false,
              contentType: false,
              processData: false,
              data: formdata,    
              type: 'post',
              success: function(data){                
                if(data==1) {
                  var roww_index = element.closest('tr').rowIndex;
                  document.getElementById('datatable-buttons').deleteRow(roww_index);
                  alert("Record Deleted Successfully");
                  location.href = location.href;
                }else{
                  alert("Error Occured ......Try again");
                }                                       
              }

             });
      
    }
}

function display_reg_cashier(){
  $("#msgModal2").fadeIn();
}

function edit_cashier(id,element){
  $("#save_new_cashier").hide();
  $("#update_cashier").show();
  var table = document.getElementById('datatable-buttons');
  var row_no = element.closest('tr').rowIndex;
  var cashier_idd = table.rows[row_no].cells[0].innerHTML;
  var names = table.rows[row_no].cells[1].innerHTML;
  var email = table.rows[row_no].cells[2].innerHTML;
  var gender = table.rows[row_no].cells[3].innerHTML;
  var priv = table.rows[row_no].cells[4].innerHTML;

  $("#cashier_idd").val(cashier_idd);

  $("#fname").val(names);
  $("#email").val(email);
  $("#gender").val('female');
  priv = priv.split(',')
  priv.shift();

  $("#readonly_priv").val(priv);
  $('#well_privv').empty();
   for(var i =0 ;i<priv.length;i++){
    if(priv[i]==1){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Message"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }else if(priv[i]==2){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Notifications"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }else if(priv[i]==3){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Dashboard"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }else if(priv[i]==4){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Menu"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }else if(priv[i]==5){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Cashiers"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }else if(priv[i]==6){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Analytics"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }else if(priv[i]==7){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Settings"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }else if(priv[i]==8){
      var id_val = "btn_c"+i;
      var btn = document.createElement("button");  
      btn.setAttribute('title','Click To Remove');
      btn.setAttribute('class', 'btn btn-round btn-primary adj_btn_margin_below');   
      btn.appendChild(document.createTextNode("Surport"));
      btn.setAttribute('id',id_val);
      btn.addEventListener("click",remove_privv.bind(null,id_val,priv[i]));  
      $('#well_privv').append(btn);
    }
  }
  display_reg_cashier();
}

function update_cashier(){
  var name = $("#fname").val();
  var email = $("#email").val();
  var gender = $("#gender").val();
  var priv = $('#readonly_priv').val();
    
   var id = $("#cashier_idd").val();

  var formdata = new FormData;
   formdata.append('fname',name);
   formdata.append('email',email);
   formdata.append('gender',gender);   
   formdata.append('priv',priv); 
   formdata.append('id',id); 
   formdata.append('stage','update_cashier');         
 
   $.ajax({
      url: '././netcrad.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
      alert(data);
        }
      });        
}

function update_settings(section){
  var formdata = new FormData;
  if(section=="general_infor"){
    var business_cat = $("#business_cat").val();
    var business_name = $("#business_name").val();
    var country   = $("#country").val();
    var city   = $("#city").val();
    var mail   = $("#mail").val();
    var description   = $("#desc").val();
    formdata.append('business_cat',business_cat);
    formdata.append('business_name',business_name);
    formdata.append('country',country);
    formdata.append('city',city);
    formdata.append('mail',mail);
    formdata.append('description',description);
    formdata.append('stage','general_infor');
  }else if(section=="manager"){
    var fname = $("#fname").val();
    var lname = $("#lname").val();
    var email = $("#email").val();
    var gender = $("#gender").val();
    var phone = $("#phone").val();
    formdata.append('fname',fname);
    formdata.append('lname',lname);
    formdata.append('email',email);
    formdata.append('gender',gender);
    formdata.append('phone',phone);
    formdata.append('stage','manager');
  }else if(section=="services"){
    var take_in = ($('#check_in').prop('checked')==true) ?  '1':  '0';
    var take_out = ($('#check_out').prop('checked')==true) ? '1': '0';
    var services = $("#services").val();
    formdata.append('take_in',take_in);
    formdata.append('take_out',take_out);
    formdata.append('services',services);
    formdata.append('stage','services');
  }else if(section=="security"){
    var notification = ($('#notification').prop('checked')==true) ?  '1':  '0';
    var log_permission = ($('#log_permision').prop('checked')==true) ? '1': '0';   
    formdata.append('notification',notification);    
    formdata.append('log_permission',log_permission);
    formdata.append('stage','security');  
  }else if(section=="ts"){
    var formdata = new FormData;  
    formdata.append('stage','ts_set')
    var select_val_t = $("#table_identity").val();
    if(select_val_t=='1' || select_val_t=='2'){
      formdata.append('table','has_data');
      var table_f = $("#ftable").val();
      var table_l = $("#ltable").val();
      if(table_f != "" && table_l != ""){
        if(select_val_t=='1'){
          var first = check_int(table_f);
          var last = check_int(table_l);
          if(first==0  || last ==0){
           alert("Input values must be numerical for Select option one");
          return null;
        }
      }else if(select_val_t=='2'){
        var letters = /^[A-Za-z]+$/;
        if(table_l.match(letters) && table_f.match(letters)){
          if(table_f.length>1 || table_l.length>1){
            alert("Only single alphabetic letters allowed...choose CUSTOM option to select preferance");
            return null;
          }
        }else{
          alert("Only Alphabetic letters allowed for Select Option 2");
          return null;
        }
      }
        formdata.append('select_val_t',select_val_t);
        formdata.append('table_f',table_f);
        formdata.append('table_l',table_l);
        formdata.append('data1','data');
      }else{
        formdata.append('data1','');
      }
    }else{
      formdata.append('table','empty');
    }

    var select_val_s = $("#seat_identity").val();
    if(select_val_s=='1' || select_val_s=='2'){
      formdata.append('seat','has_data');
      var seat_f = $("#fseat").val();
      var seat_l = $("#lseat").val();
      if(seat_f != "" && seat_l !=""){
        if(select_val_s=='1'){
          var first = check_int(seat_f);
          var last = check_int(seat_l);
          if(first==0  || last ==0){
           alert("Input values must be numerical for Select option one");
          return null;
        }
      }else if(select_val_s=='2'){
        var letters = /^[A-Za-z]+$/;
        if(seat_l.match(letters) && seat_f.match(letters)){
          if(seat_f.length>1 || seat_l.length>1){
            alert("Only single alphabetic letters allowed...choose CUSTOM option to select preferance");
            return null;
          }
        }else{
          alert("Only Alphabetic letters allowed for Select Option 2");
          return null;
        }
      }
        formdata.append('select_val_s',select_val_s);
        formdata.append('seat_f',seat_f);
        formdata.append('seat_l',seat_l);       
        formdata.append('data2','data');
      }else{
        formdata.append('data2','')
      }
    }else{
      formdata.append('seat','empty');
    }
  
  }
  $.ajax({
      url: '././netcrad.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
        alert(data);
        }
      });   
}


function send_msg(){
  
  var msg = $('#message').val();
  var formdata = new FormData;  
  if(msg){
 
    formdata.append('stage','msg');
    formdata.append('text',msg);
    $.ajax({
      url: '././netcrad.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
        $(data).appendTo('#chatbody').fadeIn();
         var scrolltoh = $('#chatbody')[0].scrollHeight;
         $('#chatbody').scrollTop(scrolltoh);
        }
      });   

  }
 
}

function load_chat(id,order_id,user_id){  
  $('#hidden_data').val(order_id+","+user_id);
  var formdata = new FormData;
   $('#status_chat').html('<i class=\"fa fa-spinner fa-spin\"> </i> Loading Content');

   formdata.append('stage','open_client_chat');
    formdata.append('id',id);
    formdata.append('order',order_id);
    $.ajax({
      url: '././netcrad.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
       $('#dcm').empty();
       $(data).appendTo('#dcm').fadeIn();         
        }
      });   
}

function business_reply_client(){ 
  var msg = $('#reply_msg').val();
  var data = $('#hidden_data').val();    
  var formdata = new FormData;  
  if(msg){ 
    formdata.append('stage','reply_msg');
    formdata.append('text',msg);
    formdata.append('data',data);
    $.ajax({
      url: '././netcrad.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
        if(data!=0){          
            $(data).appendTo('#dcm').fadeIn();
             var scrolltoh = $('#box_body_chat')[0].scrollHeight;
             $('#dcm').scrollTop(scrolltoh);
             $("#feedback_chats").load(location.href+" #feedback_chats>*"," ");
             $('#reply_msg').val('');
             var number_of_chats = $('#badge_content').text();
             var dcm_reply = $('.dcm_reply').length;

             if(dcm_reply <=  1) {               
               var adj_number_of_chats = number_of_chats - 1;
               $('#badge_content').text(adj_number_of_chats);   
               $('#feedback_client').text(adj_number_of_chats);        
             }
            }else{
            alert("Network Error");
          }
        }
      });   
   }
}

function change_fields(group){
  if(group=="table"){
    var val = $("#table_identity").val();
    if(val==3){
      $("#normal_arrangment_table").hide();
      $("#custom_arrangement_table").show();
    }else{
      $("#normal_arrangment_table").show();
      $("#custom_arrangement_table").hide();
    }
  }else if(group=="seat"){
    var val = $("#seat_identity").val();
    if(val==3){
      $("#normal_arrangment_seat").hide();
      $("#custom_arrangement_seat").show();
    }else{
      $("#normal_arrangment_seat").fadeIn();
      $("#custom_arrangement_seat").hide();
    }
  }
}

function custom_ts(group){
  if(group=='table'){
    var num_tables = $('#ntable').val();    
    if(num_tables!="" && num_tables>0){
     $("#msgModal2").show();
     $("#modal_body_ts").empty();
     for(var i=0;i<num_tables;i++){
      var input = document.createElement("input");
      input.setAttribute('type','text');      
      input.setAttribute('class', 'input_sm');
      input.setAttribute('id','num_ts'+i); 
      $(input).appendTo("#modal_body_ts").fadeIn();
     }
     
    }else{
      alert("Please enter number of table too be added");
    }
    $("#btn_save_ts").val('table,'+num_tables);
  }else if(group=='seat'){
    var num_seats = $('#nseat').val();    
    if(num_seats!="" && num_seats>0){
     $("#modal_title_ts").text("Enter Seats Identity below");
     $("#msgModal2").show();
     $("#modal_body_ts").empty();
     for(var i=0;i<num_seats;i++){
      var input = document.createElement("input");
      input.setAttribute('type','text');      
      input.setAttribute('class', 'input_sm');
      input.setAttribute('id','num_ts'+i); 
      $(input).appendTo("#modal_body_ts").fadeIn();
     }
     
    }else{
      alert("Please enter number of seats too be added");
    }
    $("#btn_save_ts").val('seat,'+num_seats);
  }
}

function save_ts(){
  var formdata =new FormData;
  var data = $("#btn_save_ts").val();
  var array = data.split(",");
  var group = array[0];
  var num = array[1];
  var num_array = [];
   for(var m =0;m<num;m++){
    var field_data = $("#num_ts"+m).val();
    if(field_data.trim() !=""){
      num_array.push(field_data);
    }
   }
   var str_array = JSON.stringify(num_array); 
   formdata.append('group',group);
   formdata.append('values',str_array);
   formdata.append('stage','save_ts');
     $.ajax({
      url: '././netcrad.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
        if(data!=0){
            alert(data);
          }else{
            alert("Network Error");
          }
        }
      });   

}

function login(){
  var formdata = new FormData;
  var email = $("#email").val().trim();
  var password = $("#password").val().trim();
  $("#alert_infor_login").html("<i class=\"fa fa-spinner fa-spin\"></i> Authenticating Information.Please wait...");
  $("#alert_infor_login").addClass('alert-warning');
  formdata.append('email',email);
  formdata.append('password',password);
  formdata.append('stage','login');

   $.ajax({
      url: '/login_auth', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
       
        if(data==0){
            window.location.href ='/orders';
        }else if(data==1){
          $("#alert_infor_login").fadeIn();
          $("#alert_infor_login").text("Login Failed....Confirm Details");
          $("#alert_infor_login").addClass('alert-danger');
        }else if(data==2){
          $("#alert_infor_login").fadeIn();
          $("#alert_infor_login").text("Network Error...try again later");
          $("#alert_infor_login").addClass('alert-danger');
        }else{
          alert(data);
        }
        }
      });   
}

function check_mail(){
  var formdata = new FormData;
  var email = $("#email").val();
  formdata.append('email',email);
  formdata.append('stage','check_mail');
  $.ajax({
      url: '/mail_exist', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: formdata,    
      type: 'post',
      success: function(data){
        if(data==1){
          $('#msg_infor').text('Email exists...Please change to proceed');
          $('#msg_infor').fadeIn();
          $('#mail_state').val('0');
        }else{
          $('#msg_infor').fadeOut();
          $('#mail_state').val('1');
        }
      }
      });   
  }

  function view_analysis(){
    
    var formdata = new FormData();
    var category = $('#meal_category').val();
    var start_date = $('#sdate').val();
    var end_date = $('#edate').val();
        
    if(category>0){
      if(start_date != ""){
        if(end_date !=""){
          formdata.append('meal_category', category);
          formdata.append('sdate', start_date);
          formdata.append('edate', end_date);
          formdata.append('stage', 'anaytics_custom');

          $.ajax({
            url: '././netcrad.php', // point to server-side PHP script 
            dataType: 'text',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: formdata,    
            type: 'post',
            success: function(data){alert(data);
              
              $('#sales_analytics_table_container').html(data);
            }
                
          });            
        }else{
           alert("Select End Date");
        }

      }else{
        alert("Select Start Date")      
      } 

    }else{
      alert("Please Select Category");
    }
    
  }





